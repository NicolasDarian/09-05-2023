<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro de Quadrados</title>
        <style>
            .desenho{
                border: 1px solid black;
                display: inline-block;
            }
        </style>
    </head>
    <body>
        <h1>Criação de quadrados</h1>
        <section>
            <form action="" method="post">
                <label for="id">ID</label>
                <input type="text" name="id" id="id">
                <br>    
                <label for="lado">Lado</label>
                <input type="text" name="lado" id="lado">
                <br>   
                <label for="cor">Cor</label>
                <input type="color" name="cor" id="cor">
                <br>
                <label for="tamanho">Tamanho</label>
                <select name="tamanho" id="tamanho">

                    <option value="cm">Centímetro</option>
                    <option value="px">píxel</option>
                    <option value="%">%</option>
                    <option value="vh">vh</option>
                    <option value="vw">vw</option>
                    
                </select>
                    
                <button type="submit" name="acao" id="acao" value="salvar">Criar</button>
            </form>
        </section>
            <hr>

    </body>
</html>
<?php 
    $id = isset($_POST['id']) ? $_POST['id'] : 0;
    $lado = isset($_POST['lado']) ? $_POST['lado'] : 0;
    $cor = isset($_POST['cor']) ? $_POST['cor'] : '';
    $tamanho = isset($_POST['tamanho']) ? $_POST['tamanho'] : 'px';
    $acao = isset($_POST['acao']) ? $_POST['acao'] : '';

    if ($acao == 'salvar') {
        try {
            require_once('classes/quadrado.class.php');
            $quadrado = new Quadrado($id, $lado, $cor, $tamanho);
            echo $quadrado->desenhar($tamanho);
            echo "<br>";
            $resultado = $quadrado->calcular();
            $medida = $_POST['tamanho'];
            echo "Área do quadrado: " . $resultado['area'] ." $medida"."<br>";
            echo "Perímetro do quadrado: " . $resultado['perimetro']." $medida";
        } catch (Exception $e) {
            echo "Erros: " . $e->getMessage();
        }
    }
    
?>