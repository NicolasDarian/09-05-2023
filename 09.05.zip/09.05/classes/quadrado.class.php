<?php

    class Quadrado {

        /*
        * Atributos da Classe
        */

        private $id; // int
        private $lado; // int
        private $cor; // string
        private $tamanho; // string

        /*
        * Construtor = definir o estado inicial do objeto
        */

        public function __construct($pid, $plado, $pcor, $ptamanho) {
            $this->setId($pid);
            $this->setLado($plado);
            $this->setCor($pcor);
            $this->setTamanho($ptamanho);
        }

        public function getId() {
            return $this->id;
        }

        public function setId($id) {
            $this->id = $id;
        }

    
        public function getLado() {
            return $this->lado;
        }


        public function setLado($lado) {
            if ($lado > 0) {
                $this->lado = $lado;
            } else {
                throw new Exception("Lado do quadrado inválido. Informe um valor maior que 0");
            }
        }

        public function getCor() {
            return $this->cor;
        }


        public function setCor($cor) {
            if ($cor != '') {
                $this->cor = $cor;
            } else {
                throw new Exception("Cor do quadrado inválido. Informe uma Cor");
            }
        }

        public function getTamanho() {
            return $this->tamanho;
        }

     
        public function setTamanho($tamanho) {
            if($tamanho != ''){
                $this->tamanho = $tamanho;
            } else{
                throw new Exception('Unidade de medida inválida. Selecione uma unidade correta');
            }
        }

        public function inserir(){}
        public function excluir(){}
        public function editar(){}
        public function listar(){}

        public function desenhar($tamanho){
            $desenho = "<div class='desenho'
                            style='
                                width:{$this->getLado()}{$this->getTamanho()};
                                height:{$this->getLado()}{$this->getTamanho()};
                                background-color:{$this->getCor()};
                            '>
                        </div>";
            return $desenho;
        }

        public function calcular()
{
    $area = $this->lado * $this->lado;
    $perimetro = 4 * $this->lado;

    return array('area' => $area, 'perimetro' => $perimetro);
}
    }

?>