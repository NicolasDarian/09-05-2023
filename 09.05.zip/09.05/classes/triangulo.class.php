<?php
class Triangulo {
    private $id;
    private $cor;    
    private $tipo;   
    private $lado1;  
    private $lado2;  
    private $lado3;  
    private $area;   

    public function __construct($id, $cor, $tipo, $lado1, $lado2, $lado3) {
        $this->id = $id;
        $this->cor = $cor;
        $this->tipo = $tipo;
        $this->lado1 = $lado1;
        $this->lado2 = $lado2;
        $this->lado3 = $lado3;
        $this->area = $this->calcularArea();
    }

    public function getId() {
        return $this->id;
    }

    public function getCor() {
        return $this->cor;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getLado1() {
        return $this->lado1;
    }

    public function getLado2() {
        return $this->lado2;
    }

    public function getLado3() {
        return $this->lado3;
    }

    public function getArea() {
        return $this->area;
    }

    private function calcularArea() {
        switch ($this->tipo) {
            case 'equilatero':
                $area = ($this->lado1 ** 2 * sqrt(3)) / 4;
                break;
            case 'isosceles':
                $base = $this->lado1 < $this->lado2 ? $this->lado1 : $this->lado2; 
                $altura = sqrt($this->lado1 ** 2 - $base ** 2);
                $area = ($base * $altura) / 2;
                break;
            case 'escaleno':
                $perimetro = $this->calcularPerimetro();
                $p = $perimetro / 2;
                $area = sqrt($p * ($p - $this->lado1) * ($p - $this->lado2) * ($p - $this->lado3));
                break;
            case 'retangulo':
                $cateto1 = $this->lado1;
                $cateto2 = $this->lado2;
                $hipotenusa = max($cateto1, $cateto2);
                if ($cateto1 == $hipotenusa) {
                    $base = $cateto2;
                } else {
                    $base = $cateto1;
                }
                $altura = $hipotenusa;
                $area = ($base * $altura) / 2;
                break;
            default:
                throw new Exception("Tipo de triângulo inválido.");
        }

        return $area;
    }

    public function montarTriangulo() {
        $triangulo = "<div style='width: 0; height: 0; border-style: solid; ";
    
        switch ($this->tipo) {
            case 'equilatero':
                $triangulo .= "border-width: {$this->lado1}px {$this->lado1}px {$this->lado1}px;";
                break;
            case 'isosceles':
                $base = $this->lado1 < $this->lado2 ? $this->lado1 : $this->lado2; 
                $altura = sqrt(pow($this->lado1, 2) - pow($base, 2)); 
                $triangulo .= "border-width: {$altura}px {$this->lado1}px {$altura}px;";
                break;
            case 'escaleno':
                $perimetro = $this->calcularPerimetro();
                $p = $perimetro / 2;
                $area = sqrt($p * ($p - $this->lado1) * ($p - $this->lado2) * ($p - $this->lado3)); 
                $base = (2 * $area) / $this->lado1; 
                $altura = (2 * $area) / $this->lado2;
                $triangulo .= "border-width: {$altura}px {$this->lado1}px {$base}px;";
                break;
            case 'retangulo':
                $triangulo .= "border-width: {$this->lado1}px {$this->lado2}px 0;";
                break;
            default:
                throw new Exception("Tipo de triângulo inválido.");
        }
    
        $triangulo .= "border-color: transparent transparent {$this->cor} transparent;'></div>";
        return $triangulo;
    }
}

?>