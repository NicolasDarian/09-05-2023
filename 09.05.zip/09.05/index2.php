<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Triângulos</title>
    <style>
        .desenho {
            display: inline-block;
        }
    </style>
</head>
<body>
    <h1>Criação de Triângulos</h1>
    <section>
        <form action="" method="post">
            <label for="id">ID</label>
            <input type="text" name="id" id="id">
            <br>    
            <label for="cor">Cor</label>
            <input type="color" name="cor" id="cor">
            <br>
            <label for="tipo">Tipo</label>
            <select name="tipo" id="tipo">
                <option value="equilatero">Equilátero</option>
                <option value="isosceles">Isósceles</option>
                <option value="escaleno">Escaleno</option>
                <option value="retangulo">Retângulo</option>
            </select>
            <br>
            <label for="lado1">Lado 1</label>
            <input type="number" name="lado1" id="lado1">
            <br>
            <label for="lado2">Lado 2</label>
            <input type="number" name="lado2" id="lado2">
            <br>
            <label for="lado3">Lado 3</label>
            <input type="number" name="lado3" id="lado3">
            <br>
            <button type="submit" name="acao" id="acao" value="criar">Criar</button>
        </form>
    </section>
    <hr>

    <?php
    require_once('classes/triangulo.class.php');

    if (isset($_POST['acao']) && $_POST['acao'] === 'criar') {
        $id = isset($_POST['id']) ? $_POST['id'] : 0;
        $cor = isset($_POST['cor']) ? $_POST['cor'] : '#000000';
        $tipo = isset($_POST['tipo']) ? $_POST['tipo'] : 'equilatero';
        $lado1 = isset($_POST['lado1']) ? floatval($_POST['lado1']) : 0;
        $lado2 = isset($_POST['lado2']) ? floatval($_POST['lado2']) : 0;
        $lado3 = isset($_POST['lado3']) ? floatval($_POST['lado3']) : 0;

        try {
            $triangulo = new Triangulo($id, $cor, $tipo, $lado1, $lado2, $lado3);
            echo $triangulo->montarTriangulo();
            echo "Área do triângulo: " . $triangulo->getArea();
        } catch (Exception $e) {
            echo "Erro: " . $e->getMessage();
        }
    }
    ?>
</body>
</html>